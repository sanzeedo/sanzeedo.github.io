/**
 * Framework-independent controller for the approved animation.
 * Load mascot.css separately. Call start() AFTER the homepage is ready.
 * canShow/onShown are synchronous adapters to the site's route/session state.
 * This module intentionally does not invent a new definition of a session.
 */
export function createCornerPeek({ imageUrl, canShow, onShown }) {
  if (!imageUrl || typeof canShow !== 'function' || typeof onShown !== 'function') {
    throw new TypeError('imageUrl, canShow() and onShown() are required');
  }
  const desktop = window.matchMedia('(min-width: 1024px)');
  let viewport = null;
  let timer = null;
  let busy = false;
  let started = false;
  let disposed = false;

  function remove() {
    clearTimeout(timer);
    timer = null;
    viewport?.remove();
    viewport = null;
    desktop.removeEventListener('change', onViewportChange);
  }
  function onViewportChange(event) {
    if (!event.matches) remove();
  }
  function eligible() {
    return !disposed && !started && desktop.matches &&
      document.visibilityState !== 'hidden' && canShow();
  }
  async function start() {
    if (busy || !eligible()) return false;
    busy = true;
    try {
      const img = document.createElement('img');
      img.className = 'dm-corner-peek__image';
      img.alt = '';
      img.draggable = false;
      img.decoding = 'async';
      img.width = 800;
      img.height = 800;
      img.src = imageUrl;
      await img.decode();
      // Route/viewport/session may have changed while decoding the asset.
      if (!eligible()) return false;

      viewport = document.createElement('div');
      viewport.className = 'dm-corner-peek';
      viewport.setAttribute('aria-hidden', 'true');
      const anchor = document.createElement('div');
      anchor.className = 'dm-corner-peek__anchor';
      const motion = document.createElement('div');
      motion.className = 'dm-corner-peek__motion';
      motion.append(img);
      anchor.append(motion);
      viewport.append(anchor);
      // Mount outside transformed/scrolled page containers.
      document.body.append(viewport);
      onShown(); // Mark this session before playback; must be synchronous.
      started = true;
      motion.classList.add('is-playing');
      desktop.addEventListener('change', onViewportChange);
      // Same duration for normal and reduced-motion playback.
      timer = setTimeout(remove, 5200);
      return true;
    } catch (error) {
      remove();
      // A missing decorative asset must not break the page or use the session.
      return false;
    } finally {
      busy = false;
    }
  }
  function destroy() {
    disposed = true;
    remove();
  }
  return { start, destroy };
}
