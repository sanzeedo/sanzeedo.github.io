// Integration pattern; replace the three adapter functions with the site's APIs.
// Include mascot.css using the project's usual stylesheet mechanism.
import { createCornerPeek } from './mascot.js';

export function mountHomepageMascot({ isHomepage, hasShownInSession, markShownInSession }) {
  const mascot = createCornerPeek({
    imageUrl: new URL('./assets/character.webp', import.meta.url).href,
    canShow: () => isHomepage() && !hasShownInSession(),
    onShown: () => markShownInSession(),
  });

  // Call this function only after the homepage's main content is ready.
  void mascot.start();

  // Wire this callback to route/component cleanup.
  return () => mascot.destroy();
}
